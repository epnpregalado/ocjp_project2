package epn.edu.ec.ocjp.core;

/**
 * Especifica la clase ruta
 * @author jpatrick
 *
 */
public class Ruta {

	String ruta;

	public String getRuta() {
		return ruta;
	}

	public void setRuta(String ruta) {
		this.ruta = ruta;
	}
	
}
