package epn.edu.ec.ocjp.core;

import java.sql.Date;

/**
 * Entidad que define la clase Horario
 * @author jpatrick
 *
 */
public class Horario {

	private Date fechaSalida;
	private Date fechaArribo;
	
	public Date getFechaSalida() {
		return fechaSalida;
	}
	public void setFechaSalida(Date fechaSalida) {
		this.fechaSalida = fechaSalida;
	}
	public Date getFechaArribo() {
		return fechaArribo;
	}
	public void setFechaArribo(Date fechaArribo) {
		this.fechaArribo = fechaArribo;
	}
	
}
