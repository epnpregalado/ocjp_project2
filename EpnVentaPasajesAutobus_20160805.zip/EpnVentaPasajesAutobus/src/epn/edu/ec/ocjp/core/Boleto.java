package epn.edu.ec.ocjp.core;

import java.util.Scanner;

/**
 * Especifica la clase boletos
 * @author jpatrick
 *
 */
public class Boleto {

	private Pasajero pasajero;
	private double valor;
	private double iva;
	private static DatosBoleto datosBoleto;
	
	public static void main(String [] args) {
		System.out.println("============================================================");
		System.out.println("                  TERMINAL AUTOBUS EPN                      ");
		System.out.println("============================================================");
		String entradaTeclado = "";
		datosBoleto = new DatosBoleto();
		do{
			System.out.println("1. Ver autobus");
			System.out.println("2. Ingresar autobus");
			System.out.println("3. Ingresar ruta");
			System.out.println("4. Ingresar horario");

			Scanner entradaEscaner = new Scanner (System.in);
			entradaTeclado = entradaEscaner.nextLine(); 

			switch (entradaTeclado) {

			case "1":
				datosBoleto.mostrarCatalogoAutoBus();
				break;
			case "2":
				datosBoleto.ingresarAutoBus();
				break;
			case "3":
				datosBoleto.ingresarRuta();
				break;
			default:
				System.out.println("...");
				break;

			}
		} while (datosBoleto.getAutobus() == null && 
				datosBoleto.getHorario() == null && 
				datosBoleto.getRuta() == null);
		System.out.println(datosBoleto);
	}
	
	/*
	 * Getters and setters
	 */
	
	public Pasajero getPasajero() {
		return pasajero;
	}
	public void setPasajero(Pasajero pasajero) {
		this.pasajero = pasajero;
	}
	public double getValor() {
		return valor;
	}
	public void setValor(double valor) {
		this.valor = valor;
	}
	public double getIva() {
		return iva;
	}
	public void setIva(double iva) {
		this.iva = iva;
	}

	public DatosBoleto getDatosBoleto() {
		return datosBoleto;
	}

	public void setDatosBoleto(DatosBoleto datosBoleto) {
		this.datosBoleto = datosBoleto;
	}
}
