package epn.edu.ec.ocjp.core;

/**
 * Especifica la clase Pasajero
 * @author jpatrick
 *
 */
public class Pasajero {

	private String nombre;
	private String cedula;
	
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getCedula() {
		return cedula;
	}
	public void setCedula(String cedula) {
		this.cedula = cedula;
	}
	
}
